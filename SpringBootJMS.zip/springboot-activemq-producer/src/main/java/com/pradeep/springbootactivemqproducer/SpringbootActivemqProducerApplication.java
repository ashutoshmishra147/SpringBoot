package com.pradeep.springbootactivemqproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootActivemqProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootActivemqProducerApplication.class, args);
	}

}
