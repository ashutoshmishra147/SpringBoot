package com.pradeep.springbootactivemqconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootActivemqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
