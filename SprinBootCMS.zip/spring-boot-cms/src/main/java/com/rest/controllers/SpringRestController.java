package com.rest.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/test")
@RestController
public class SpringRestController {

	public SpringRestController() {
	System.out.println("Rest Controller created....");
	}
	
	
	@GetMapping("/hi")
	public String hiGET(){
		return "Hi GET";
	}
	
	@PostMapping("/hi")
	public String hiPOST(){
		return "Hi POST";
	}
	
	
	@DeleteMapping("/hi")
	public String hiDELETE(){
		return "Hi DELETE";
	}
	
	@PutMapping("/hi")
	public String hiPUT(){
		return "Hi PUT";
	}
	
	@PatchMapping("/hi")
	public String hiPATCH(){
		return "Hi PATCH";
	}
	
	
}
